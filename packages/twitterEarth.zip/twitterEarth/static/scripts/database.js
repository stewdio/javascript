

//  This is all you need in this file.

var database = []


//  However, it’s nice to have an example to work from.
//  Below is the result of running the "exportTweets()" function from the
//  console and then copying + pasting that result into this file.
//  It’s that simple.
//  You can load whatever’s in here back into your "tweets[]" array by using
//  the "importTweets()" command in the console.

database = database.concat([
	{
		latitude:  -23.5489433,
		longitude: -46.6388182
	},
	{
		latitude:  27.2494854,
		longitude: 33.81828089999999
	},
	{
		latitude:  43.915886,
		longitude: 17.67907600000001
	},
	{
		latitude:  43.2381999,
		longitude: 76.91905980000001
	},
	{
		latitude:  35.20105,
		longitude: -91.8318334
	},
	{
		latitude:  -29.918889,
		longitude: -51.17805870000001
	},
	{
		latitude:  -29.534505,
		longitude: -53.39060740000002
	},
	{
		latitude:  55.604981,
		longitude: 13.003822000000014
	},
	{
		latitude:  38.2656759,
		longitude: -122.65120000000002
	},
	{
		latitude:  51.5101372,
		longitude: -0.13409899999999197
	},
	{
		latitude:  -5.1166667,
		longitude: 105.29999999999995
	},
	{
		latitude:  39.39987199999999,
		longitude: -8.224454000000037
	},
	{
		latitude:  46.98355,
		longitude: 12.891679999999951
	},
	{
		latitude:  -15.5989173,
		longitude: -56.09489400000001
	},
	{
		latitude:  40.46366700000001,
		longitude: -3.7492200000000366
	},
	{
		latitude:  -23.5489433,
		longitude: -46.6388182
	},
	{
		latitude:  -33.3579416,
		longitude: -70.7451446
	},
	{
		latitude:  43.9293335,
		longitude: 2.8923862999999983
	},
	{
		latitude:  -31.3989296,
		longitude: -64.18212890000001
	},
	{
		latitude:  48.856614,
		longitude: 2.3522219000000177
	},
	{
		latitude:  39.39987199999999,
		longitude: -8.224454000000037
	},
	{
		latitude:  -22.9035393,
		longitude: -43.20958689999998
	},
	{
		latitude:  33.854721,
		longitude: 35.86228499999993
	},
	{
		latitude:  -14.235004,
		longitude: -51.92527999999999
	},
	{
		latitude:  -22.7249765,
		longitude: -47.64760060000003
	},
	{
		latitude:  -14.235004,
		longitude: -51.92527999999999
	},
	{
		latitude:  -23.655314,
		longitude: -46.5320878
	},
	{
		latitude:  -12.9703817,
		longitude: -38.512382
	},
	{
		latitude:  -14.235004,
		longitude: -51.92527999999999
	},
	{
		latitude:  -32.0319414,
		longitude: -52.09960739999997
	},
	{
		latitude:  -27.0080354,
		longitude: -51.152297799999985
	}
])

