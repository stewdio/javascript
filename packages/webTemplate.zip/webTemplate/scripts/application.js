$( document ).ready( function(){
	
	
	
	
	//  This is where all your awesome JavaScript code goes...

	
	
	
})